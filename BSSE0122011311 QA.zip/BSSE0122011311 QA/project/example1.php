<!DOCTYPE html>
<html lang="en">
<head>
   <form action="example.php" method="POST">
    <input type="radio" name="catagary" value= "Chair">
    <input type="submit" name="submit">
   </form>
</head>
<body>
    
</body>
</html>