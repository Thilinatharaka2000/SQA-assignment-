

<?php

require 'sellerIntaface.php'; 

use PHPUnit\Framework\TestCase;

class sellerIntafaceTest extends TestCase
{
    public function testsellerIntafaceFunction() {
        $result = sellerIntafaceFunction('expected_value'); 
        $this->assertEquals('expected output', $result); 

        $result = sellerIntafaceFunction('unexpected_value'); 
        $this->assertEquals('unexpected output', $result); 
    }
}
?>
