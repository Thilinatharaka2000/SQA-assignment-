# Password Reset System
You can fine the explanation of the code in youtube video https://youtu.be/zUFcjOt_ytk

Before you use the code, edit following files.
1. change_password_process.php, in line-5 edit database connection.
2. forgot_password_process.php, from line-23 to line-39 edit for email. in line-41 edit for database connection.

<img width="960" alt="2021-02-08" src="https://user-images.githubusercontent.com/11453784/107498379-d023de00-6bbb-11eb-9353-da74bd9b1acb.png">
